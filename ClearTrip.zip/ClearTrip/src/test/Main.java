package test;

import org.testng.annotations.Test;

import browserutilities.LaunchingBrowser;
import pagefunctions.PageFunctions;

public class Main extends LaunchingBrowser {
  @Test
  public void start() {
	  
	  PageFunctions pf=new PageFunctions();
	  pf.performFunctions(driver);
  }
}
