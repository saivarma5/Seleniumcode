package pagefunctions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import propertiesutilities.ReadDataFromPropertiesFile;

public class PageFunctions {
	ReadDataFromPropertiesFile rd = new ReadDataFromPropertiesFile();

	By roundTrip = By.xpath("//input[@value='RoundTrip']");
	By from = By.xpath("//input[@data-idfield='from']");
	By fromDropDown = By.xpath("//a[text()='Chennai, IN - Chennai Airport (MAA)']");
	By to = By.xpath("//input[@data-idfield='to']");
	By toDropDown=By.xpath("//a[text()='Munich, DE - Munich (MUC)']");
	By departDate=By.xpath("(//a[text()='14'])[1]");
	By returns=By.xpath("(//i[@class=\"icon ir datePicker\"])[2]");
	By returnDate=By.xpath("(//a[text()='21'])[1]");
	By adults=By.xpath("//select[@id='Adults']");
	By search=By.xpath("//input[@id='SearchBtn']");
	By book=By.xpath("(//button[@class='booking'])[1]");

	public void performFunctions(WebDriver driver) {
		driver.findElement(roundTrip).click();
		driver.findElement(from).click();
		driver.findElement(from).sendKeys(rd.readData("from"));
		driver.findElement(fromDropDown).click();
		driver.findElement(to).sendKeys(rd.readData("to"));
		driver.findElement(toDropDown).click();
		driver.findElement(departDate).click();
		driver.findElement(returns).click();
		driver.findElement(returnDate).click();
		Select sel=new Select(driver.findElement(adults));
		sel.selectByValue(rd.readData("adults"));
		
		driver.findElement(search).click();
	
		/*WebDriverWait wait=new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(book)));*/
		driver.findElement(book).click();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
