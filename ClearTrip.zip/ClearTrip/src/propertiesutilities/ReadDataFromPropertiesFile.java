package propertiesutilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ReadDataFromPropertiesFile {
public String readData(String name) {
	Properties prop=new Properties();
	try {
		FileInputStream fis=new FileInputStream("F:\\Eclipse1\\Selenium\\ClearTrip\\src\\propertiesfile\\data.properties");
		prop.load(fis);
		return prop.getProperty(name);
	} catch (Exception e) {
     System.out.println("Properties file not found in the given path");
     return null;
	}
	

}
}
